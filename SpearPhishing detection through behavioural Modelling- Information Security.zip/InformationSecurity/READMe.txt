To run the program simply run test.py file.
It will give you the required results.

If you want to change the model to cater to another users habits follow these steps.
1. Download the data from the link :- https://www.cs.cmu.edu/~enron/enron_mail_20150507.tar.gz.
2. Set the correct path directories in DataProcessing.py
3. Change the name of the user in DataProcessing.py
4. Run Test.py